
import { StyleSheet, View, Text, } from 'react-native';
export default function MovieScreen() {
    return (
        <View style={styles.container}>
            <View style={styles.Movies}>
                <Text>heloo</Text>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
    },
    Movies: {
        backgroundColor: "black",

    }


});
