
import { StyleSheet, Text, View, ImageBackground, Image, TouchableOpacity } from 'react-native';
import MovieScreen from '../../MovieScreen';

export default function Header() {
    return (



        <ImageBackground
            source={require('../Icons/nav_bar.png')}
            style={styles.backgroundImage}
        >
            <Image source={require('../Icons/Back.png')} style={styles.Image}></Image>
            <Text style={styles.title}>Romantic Comedy</Text>
            <TouchableOpacity>
                <Image source={require('../Icons/search.png')} style={styles.Image2}></Image>
            </TouchableOpacity>
        </ImageBackground>



    );
}

const styles = StyleSheet.create({


    backgroundImage: {
        height: 80,
        flexDirection: 'row',
        alignItems: 'center',

    },
    title: {
        fontSize: 20,
        fontWeight: 'normal',
        color: '#999999',
        textAlign: 'right',

    },
    Image: {
        height: 20,
        width: 20,
        marginHorizontal: 15

    },
    Image2: {
        height: 20,
        width: 20,
        marginStart: 120
    }

});
