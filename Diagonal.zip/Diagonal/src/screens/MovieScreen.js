import React from 'react';
import { StyleSheet, View, Text, ScrollView, useState, Button, Image } from 'react-native';
import { Header, MovieCard } from "../components";
import data1 from '../Json/CONTENTLISTINGPAGE-PAGE1.js';
import data2 from '../Json/CONTENTLISTINGPAGE-PAGE2.js';
import data3 from '../Json/CONTENTLISTINGPAGE-PAGE3.js';
const DataComponent = () => {

    const movieCards = data1.contentItems.map((item) => {
        return (
            <MovieCard title={item.name}
                image={item.posterImage}
            />
        );
    }
    );
    return movieCards;
}
const DataComponent2 = () => {

    const movieCards = data2.contentItems.map((item) => {
        return (
            <MovieCard title={item.name}
                image={item.posterImage}
            />
        );
    }
    );
    return movieCards;
}
const DataComponent3 = () => {

    const movieCards = data3.contentItems.map((item) => {
        return (
            <MovieCard title={item.name}
                image={item.posterImage}
            />
        );
    }
    );
    return movieCards;
}

const MovieScreen = () => {

    return (
        <View style={styles.container}>
            <Header />

            <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollwrapper}>
                <View style={styles.Scroll}>
                    <DataComponent />
                    <DataComponent2 />
                    <DataComponent3 />
                </View>
            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {

    },
    movieCardWrapper: {
        padding: 10,
        flexDirection: 'row',
        alignItems: 'center',

    },
    scrollwrapper: {


        marginBottom: 10

    },
    movieCardRow: {
        justifyContent: 'space-between',
        paddingHorizontal: 10,
        marginBottom: 10,
    },
    Scroll:
    {
        gap: 5,
        flexDirection: 'row',
        flexWrap: 'wrap'
    }
});

export default MovieScreen;