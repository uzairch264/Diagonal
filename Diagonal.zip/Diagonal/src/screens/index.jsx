import MovieScreen from "./MovieScreen";

export { MovieScreen }