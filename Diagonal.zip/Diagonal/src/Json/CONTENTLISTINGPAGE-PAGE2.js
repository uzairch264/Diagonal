;
const romanticComedy2 = {

  title: "Romantic Comedy",
  totalContentItems: "54",
  pageNumRequested: "2",
  pageSizeRequested: "20",
  pageSizeReturned: "20",
  contentItems: [

    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
    {
      name: "Family Pot",
      posterImage: require("../assets/jpgs/poster6.jpg"),
    },
    {
      name: "Family Pot",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster4.jpg"),
    },
    {
      name: "The Birds",
      posterImage: require("../assets/jpgs/poster6.jpg"),
    },
    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster6.jpg"),
    },
    {
      name: "The Birds",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
    {
      name: "Family Pot",
      posterImage: require("../assets/jpgs/poster4.jpg"),
    },
    {
      name: "The Birds",
      posterImage: require("../assets/jpgs/poster4.jpg"),
    },
    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
    {
      name: "Family Pot",
      posterImage: require("../assets/jpgs/poster6.jpg"),
    },
    {
      name: "Family Pot",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster4.jpg"),
    },
    {
      name: "The Birds",
      posterImage: require("../assets/jpgs/poster6.jpg"),
    },
    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster6.jpg"),
    },
    {
      name: "The Birds",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
    {
      name: "Family Pot",
      posterImage: require("../assets/jpgs/poster4.jpg"),
    },
    {
      name: "The Birds",
      posterImage: require("../assets/jpgs/poster4.jpg"),
    },
    {
      name: "Rear Window",
      posterImage: require("../assets/jpgs/poster5.jpg"),
    },
  ],


};
export default romanticComedy2;