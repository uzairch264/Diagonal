const romanticComedy3 = {

    title: "Romantic Comedy",
    totalContentItems: "54",
    pageNumRequested: "3",
    pageSizeRequested: "20",
    pageSizeReturned: "14",
    contentItems: [

        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster9.jpg"),
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster8.jpg"),
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster7.jpg"),
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster9.jpg"),
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster9.jpg"),
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster8.jpg"),
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster7.jpg"),
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster9.jpg"),
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster8.jpg"),
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster7.jpg"),
        },
        {
            name: "The Birds with an Extra Long Title",
            posterImage: require("../assets/jpgs/poster8.jpg"),
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster9.jpg"),
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster8.jpg"),
        },
        {
            name: "Family Pot",
            posterImage: "posterthatismissing.jpg",
        },
    ],


};

export default romanticComedy3;
