
// import React from 'react';
// import { View, Text, useState } from 'react-native';
// const [movies, setMovies] = useState([]);
// const loadMovies = async () => {
//     const jsonData1 = require('./CONTENTLISTINGPAGE-PAGE1.json');
//     const jsonData2 = require('./CONTENTLISTINGPAGE-PAGE2.json');
//     const jsonData3 = require('./CONTENTLISTINGPAGE-PAGE3.json');

//     const moviesData = await json.parse(jsonData1);
//     setMovies(moviesData['content-items']['content']);

// };

// useEffect(() => {
//     loadMovies();
// }, []);
// const RenderMovies = () => {
//     return movies.map((movie, index) => (
//         <View key={index}>
//             <Text>{movie['name']}</Text>
//             <Text>{movie['poster-image']}</Text>
//         </View>
//     ));
// };
// export default RenderMovies;