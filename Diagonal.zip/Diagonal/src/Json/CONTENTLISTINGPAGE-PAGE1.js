const romanticComedy = {
    title: "Romantic Comedy",
    totalContentItems: 54,
    pageNumRequested: 1,
    pageSizeRequested: 20,
    pageSizeReturned: 20,
    contentItems: [
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster2.jpg")
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster3.jpg")
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster2.jpg")
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster3.jpg")
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster3.jpg")
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster2.jpg")
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster2.jpg")
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster3.jpg")
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster3.jpg")
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster3.jpg")
        },
        {
            name: "Rear Window",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster2.jpg")
        },
        {
            name: "Family Pot",
            posterImage: require("../assets/jpgs/poster1.jpg")
        },
        {
            name: "The Birds",
            posterImage: require("../assets/jpgs/poster1.jpg")
        }
    ]
};

export default romanticComedy;