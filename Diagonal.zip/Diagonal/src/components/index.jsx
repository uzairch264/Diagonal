import Header from "./Header";
import MovieCard from "./MovieCard";

export { Header, MovieCard }