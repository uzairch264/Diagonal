import React from "react";
import { View, Text, StyleSheet, Image } from "react-native";


const MovieCard = ({ title, image }) => {
    return (
        <View style={styles.cardContainer}>
            <Image resizeMode="cover" style={styles.posterImage} source={image} />
            <Text style={styles.posterTitle}>{title}</Text>
        </View>
    );
};

const styles = StyleSheet.create({
    cardContainer: {
        maxHeight: 200,
        height: 200,
        width: 122,
        marginBottom: 30,

    },
    posterImage: {
        width: '90%',
        height: '90%',
    },
    posterTitle: {
        fontSize: 16,
        lineHeight: 20,
        marginTop: 3,
        fontWeight: '400',
        color: 'white',
    }
})

export default MovieCard;