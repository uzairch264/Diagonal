import React from 'react';
import { StyleSheet, Text, ImageBackground, Image, TouchableOpacity, View, TextInput } from 'react-native';

// import navBar from "../assets/pngs/nav_bar.png";
// import backArrow from "../assets/pngs/Icons/Back.png";
// import searchIcon from "../assets/pngs/Icons/search.png";
import NavBar from "../assets/pngs/nav_bar.png";
import BackArrow from "../assets/pngs/Back.png";
import SearchIcon from "../assets/pngs/search.png"

const Header = () => {
    return (
        <ImageBackground
            source={NavBar}
            style={styles.backgroundImage}>
            <TouchableOpacity>
                <Image source={BackArrow} style={styles.backArrow} />
            </TouchableOpacity>
            <View style={styles.inputWrapper}>
                <TextInput placeholderTextColor="white" style={styles.textInput} placeholder='Romantic Comedy' />
                <Image source={SearchIcon} style={styles.searchIcon} />
            </View>
        </ImageBackground>
    );
}

const styles = StyleSheet.create({
    backgroundImage: {
        height: 80,
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        zIndex: 1,
        position: 'relative'
    },
    title: {
        fontSize: 20,
        fontWeight: 'normal',
        color: '#999999',
        textAlign: 'right',
    },
    backArrow: {
        height: 20,
        width: 20,
        marginHorizontal: 15
    },
    searchIcon: {
        width: 20,
        height: 20,
        marginLeft: 0
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    textInput: {
        width: '84%',
        fontSize: 22,
        lineHeight: 26,
        fontWeight: '500',
        color: 'white'
    }
});

export default Header;